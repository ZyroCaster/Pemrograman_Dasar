package com.example.viewpager_trialfinal

class myfriend (
    val nama:String,
    val jkel:String,
    val email:String,
    val telp:String,
    val alamat:String
)