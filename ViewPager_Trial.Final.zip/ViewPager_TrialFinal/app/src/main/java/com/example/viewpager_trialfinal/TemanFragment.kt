package com.example.viewpager_trialfinal

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.clearFindViewByIdCache
import kotlinx.android.synthetic.main.fragment_teman.rv_listmyfriends
import org.jetbrains.annotations.Nullable

class TemanFragment : Fragment(){
    lateinit var listTeman:ArrayList<myfriend>

    private fun simulasiDataTeman(){
        listTeman= ArrayList()
        listTeman.add(
            myfriend("Eko Nomi Sul Eet","Laki Laki","123@e4321", "080808",
            "Gedangan")
        )
        listTeman.add(
            myfriend("Ho Lee Fuk", "China", "yoi@lur", "090909",
            " Buduran")
        )
    }

    private fun tampilTeman(){
        rv_listmyfriends.layoutManager=LinearLayoutManager(activity)
        rv_listmyfriends.adapter=myfriendadapter(activity!!,listTeman)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_teman, container, false)
    }

    override fun onViewCreated(view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        intView()
    }

    private fun intView(){
        simulasiDataTeman()
        tampilTeman()
    }

    override fun onDestroy() {
        super.onDestroy()
        this.clearFindViewByIdCache()
    }
}